=== Plugin Name ===
Contributors: cristian.raiber, colorlib
Tags: Facebook, facebook connect, facebook like, facebook share, facebook share icon, floating buttons, floating share, floating share icons, follow, google, Google Login, google plus, icons, increase shares, linkedin, linkedin share, media, page, pinterest, pinterest button, pinterest share, plugin, post to social networks, Reddit, reddit share, reddit sharing, Share, share button, share buttons, share counter, share icons, share links, share page, share post, sharebar, sharing, sharing icons, social, social app, social buttons, social comment, social comment facebook, social connect, social floating icons, social follow, social icon, social icons, social media, social media app, social media buttons, Social Media Plugins, social media share, social media sharing, social media tools, social network share, Social Plugins, social provider, social share, Social Share Buttons, social share icon, social share icons, social sharing, social sharing icons, social widget, stumbleupon sharing, tumblr share, tumblr sharing, twitter, twitter share, woocommerce, woocommerce connect, woocommerce sharing, yahoo
Requires at least: 3.8
Tested up to: 4.5.2
Stable tag: 1.0.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Social share floating icons helps you to share content easily on the web. Using the stylish social share floating icons your users will share your content in a fun way. Social share floating icons comes with alot of stylish icons and with many hover over animations you'll love to see. Animations on social share icons will let your user share your content in a fun way

== Description ==


* Four different Skins
* Add Social Sharing icons on Left of your Post
* Add Social Sharing icons on Right of your Post
* Add social Sharing icons on Top of your Post
* Add social Sharing icons at Bottom of your Post
* Add social Sharing icons on Both Top and Bottom of your Post
* Set your margin top of social share icons from your header
* Set margin between icons of social share icons
* Simple social share icons configuration and design
* Easy to setup with just simple and easy options

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the whole contents of the folder `kiwi-social-share` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Enjoy using it :)




== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.0.0 =
* Initial release